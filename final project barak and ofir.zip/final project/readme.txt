##### AI project #####
- barak zan 305634487
- ofir shomron 201450574

instructions: 

to activate the project - cd to this folder and run "python weatherForecast\experiments.py"
it will prepare all the data, run some expirements and then plot the graphs.

it may take more then ten min.